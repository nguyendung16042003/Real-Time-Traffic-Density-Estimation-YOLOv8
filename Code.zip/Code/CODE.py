import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cv2
from ultralytics import YOLO
import yaml  
from PIL import Image  # Import thư viện Image để xử lý hình ảnh

#----------------------------------------------------------

# Tải mô hình YOLO
model = YOLO('yolov8n.pt')

#---------------------- Fine-Tuning YOLOv8 ------------------------------------

# Đường dẫn đến thư mục chứa dữ liệu huấn luyện
data_path = r"E:\DOWLOAD\MUSIC\Anh Visual code\Training\xe ba cang.v1i.yolov8\data.yaml"

# Thư mục mà bạn muốn lưu mô hình sau khi huấn luyện
save_dir = "E:/DOWLOAD/MUSIC/Anh Visual code/Training/Vehicle_Detection_Image_Dataset/train"

# Kiểm tra nếu mô hình đã huấn luyện có sẵn
model_path = os.path.join(save_dir, 'custom_yolov8', 'weights', 'best.pt')
if os.path.exists(model_path):
    model = YOLO(model_path)  # Tải mô hình đã huấn luyện
    print(f"Tải lại mô hình đã huấn luyện từ: {model_path}")
else:
    print("Mô hình huấn luyện chưa có, bắt đầu huấn luyện lại mô hình.")

    # Huấn luyện mô hình và chỉ định nơi lưu mô hình
    model.train(
        data=data_path,          # Đường dẫn đến file dữ liệu của bạn
        epochs=50,               # Số lượng epochs
        batch=4,                 # Kích thước batch giảm xuống còn 4
        imgsz=320,               # Giảm kích thước ảnh xuống 320 để giảm yêu cầu bộ nhớ
        name="custom_yolov8",    # Tên mô hình để lưu
        project=save_dir,        # Thư mục lưu kết quả huấn luyện
        workers=2                # Số luồng để tải dữ liệu
    )

# Sau khi huấn luyện xong, mô hình sẽ được lưu trong thư mục đã chỉ định 'save_dir'
# Tên mô hình tốt nhất sẽ là 'best.pt'

# Tải lại mô hình đã huấn luyện
model = YOLO(f"{save_dir}/custom_yolov8/weights/best.pt")  # Đường dẫn đến mô hình đã huấn luyện

# Đường dẫn đến thư mục chứa các ảnh cần kiểm tra
test_image_folder = r"E:\DOWLOAD\MUSIC\Anh Visual code\Training\xe ba cang.v1i.yolov8\train\images"  # Thay bằng đường dẫn đúng đến thư mục chứa 500 ảnh

# Kiểm tra nếu thư mục chứa ảnh tồn tại
if not os.path.exists(test_image_folder):
    print(f"Thư mục {test_image_folder} không tồn tại!")
else:
    # Duyệt qua tất cả các ảnh trong thư mục và thực hiện suy luận
    image_paths = [os.path.join(test_image_folder, fname) for fname in os.listdir(test_image_folder) 
                   if fname.endswith(('.jpg', '.jpeg', '.png'))]

    # Kiểm tra nếu có ảnh trong thư mục
    if len(image_paths) == 0:
        print(f"Không tìm thấy ảnh nào trong thư mục {test_image_folder}!")
    else:
        print(f"Đang kiểm tra {len(image_paths)} ảnh...")

        # Dự đoán tất cả ảnh trong thư mục
        results = model.predict(image_paths)  # Sử dụng danh sách ảnh đã tạo từ thư mục

        # Hiển thị kết quả nhận diện của ảnh đầu tiên trong danh sách
        results[0].show()  # Hiển thị tất cả kết quả nhận diện của ảnh đầu tiên

        # Lưu kết quả vào thư mục mặc định
        for result in results:
            result.save()  # Lưu kết quả của từng ảnh

        print("Đã hoàn thành việc kiểm tra và lưu kết quả!")


#------------------ Ảnh được resize về 640x640 và ngưỡng độ tin cậy 50%----------------------------------------
# Path to the image file
image_path = "E:\DOWLOAD\MUSIC\Anh Visual code\Training\Vehicle_Detection_Image_Dataset\sample_image.jpg"

# Perform inference on the provided image(s)
results = model.predict(source=image_path, 
                        imgsz=640,  # Resize image to 640x640 (the size pf images the model was trained on)
                        conf=0.5)   # Confidence threshold: 50% (only detections above 50% confidence will be considered)

# Annotate and convert image to numpy array
sample_image = results[0].plot(line_width=2)

# Convert the color of the image from BGR to RGB for correct color representation in matplotlib
sample_image = cv2.cvtColor(sample_image, cv2.COLOR_BGR2RGB)

# Display annotated image
plt.figure(figsize=(20,15))
plt.imshow(sample_image)
plt.title('Detected Objects in Sample Image by the Pre-trained YOLOv8 Model on COCO Dataset', fontsize=20)
plt.axis('off')
plt.show()

#----------------------Chạy video xác định mật độ------------------------------------

# Mở file video chứa đối tượng để xử lý
cap = cv2.VideoCapture(r"E:\DOWLOAD\MUSIC\DemDoiTuong_Yolo8-main\DemDoiTuong_Yolo8-main\t7.mp4")
assert cap.isOpened(), "Lỗi đọc file"

# Lấy chiều dài, rộng và số frame của video
w, h, fps = (int(cap.get(x)) for x in (cv2.CAP_PROP_FRAME_WIDTH, cv2.CAP_PROP_FRAME_HEIGHT, cv2.CAP_PROP_FPS))

# Định nghĩa ngưỡng để coi là mật độ giao thông nặng
heavy_traffic_threshold = 10

# Định nghĩa các đỉnh của đa giác cho hai làn đường
vertices1 = np.array([(465, 350), (609, 350), (500, 650), (2, 630)], dtype=np.int32)
vertices2 = np.array([(678, 350), (815, 350), (1230, 650), (755, 650)], dtype=np.int32)

# Định nghĩa phạm vi dọc cho vùng theo dõi và ngưỡng của làn đường
x1, x2 = 325, 635 
lane_threshold = 609

# Định vị trí cho các chú thích văn bản trên ảnh
text_position_left_lane = (10, 50)
text_position_right_lane = (820, 50)
intensity_position_left_lane = (10, 100)
intensity_position_right_lane = (820, 100)

# Cài đặt font chữ, kích thước và màu sắc cho các chú thích
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 1
font_color = (255, 255, 255)    # Màu trắng cho chữ
background_color = (0, 0, 255)  # Màu đỏ cho nền chữ

# Định nghĩa codec và tạo đối tượng VideoWriter để lưu video đã xử lý
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('traffic_density_analysis.avi', fourcc, fps, (w, h))

# Lặp qua các frame để xử lý
paused = False  # Biến để kiểm soát trạng thái tạm dừng
while cap.isOpened():
    if not paused:  # Chỉ đọc frame mới khi không ở trạng thái tạm dừng
        success, frame = cap.read()
        if not success:
            print("Kết thúc video.")
            break

        # Tạo bản sao của khung hình để chỉnh sửa
        detection_frame = frame.copy()

        # Làm đen các vùng ngoài phạm vi dọc xác định
        detection_frame[:x1, :] = 0  # Làm đen từ đỉnh đến x1
        detection_frame[x2:, :] = 0  # Làm đen từ x2 xuống đáy

        # Sử dụng YOLO để dự đoán đối tượng trên khung hình đã chỉnh sửa
        results = model(detection_frame, imgsz=640, conf=0.4)
        processed_frame = results[0].plot(line_width=1)

        # Phục hồi lại các phần trên và dưới của khung hình ban đầu
        processed_frame[:x1, :] = frame[:x1, :].copy()
        processed_frame[x2:, :] = frame[x2:, :].copy()

        # Vẽ các đa giác trên khung hình đã xử lý
        cv2.polylines(processed_frame, [vertices1], isClosed=True, color=(0, 255, 0), thickness=2)
        cv2.polylines(processed_frame, [vertices2], isClosed=True, color=(255, 0, 0), thickness=2)

        # Lấy các bounding box từ kết quả dự đoán
        bounding_boxes = results[0].boxes

        # Khởi tạo bộ đếm cho các đối tượng ở mỗi làn
        vehicles_in_left_lane = 0
        vehicles_in_right_lane = 0

        # Lặp qua từng bounding box và nhãn để đếm các đối tượng
        for box, label in zip(bounding_boxes.xyxy, bounding_boxes.cls):
            object_name = results[0].names[int(label)]  # Tên của đối tượng theo nhãn YOLO

            # Kiểm tra nếu đối tượng là xe máy, ô tô, xe tải, người đi bộ hoặc xe đạp
            if object_name in ["motorbike", "car", "truck", "person", "bicycle"]:
                if box[0] < lane_threshold:
                    vehicles_in_left_lane += 1
                else:
                    vehicles_in_right_lane += 1

        # Xác định cường độ giao thông cho làn trái
        if vehicles_in_left_lane == 0:
            traffic_intensity_left = "Free-flow"
        elif vehicles_in_left_lane > heavy_traffic_threshold:
            traffic_intensity_left = "Heavy"
        else:
            traffic_intensity_left = "Smooth"

        # Xác định cường độ giao thông cho làn phải
        if vehicles_in_right_lane == 0:
            traffic_intensity_right = "Free-flow"
        elif vehicles_in_right_lane > heavy_traffic_threshold:
            traffic_intensity_right = "Heavy"
        else:
            traffic_intensity_right = "Smooth"

        # Thêm chú thích số lượng xe và cường độ giao thông trên khung hình
        cv2.rectangle(processed_frame, (text_position_left_lane[0]-10, text_position_left_lane[1] - 25), 
                      (text_position_left_lane[0] + 460, text_position_left_lane[1] + 10), background_color, -1)
        cv2.putText(processed_frame, f'Vehicles in Left Lane: {vehicles_in_left_lane}', text_position_left_lane, 
                    font, font_scale, font_color, 2, cv2.LINE_AA)

        cv2.rectangle(processed_frame, (intensity_position_left_lane[0]-10, intensity_position_left_lane[1] - 25), 
                      (intensity_position_left_lane[0] + 460, intensity_position_left_lane[1] + 10), background_color, -1)
        cv2.putText(processed_frame, f'Traffic Intensity: {traffic_intensity_left}', intensity_position_left_lane, 
                    font, font_scale, font_color, 2, cv2.LINE_AA)

        cv2.rectangle(processed_frame, (text_position_right_lane[0]-10, text_position_right_lane[1] - 25), 
                      (text_position_right_lane[0] + 460, text_position_right_lane[1] + 10), background_color, -1)
        cv2.putText(processed_frame, f'Vehicles in Right Lane: {vehicles_in_right_lane}', text_position_right_lane, 
                    font, font_scale, font_color, 2, cv2.LINE_AA)

        cv2.rectangle(processed_frame, (intensity_position_right_lane[0]-10, intensity_position_right_lane[1] - 25), 
                      (intensity_position_right_lane[0] + 460, intensity_position_right_lane[1] + 10), background_color, -1)
        cv2.putText(processed_frame, f'Traffic Intensity: {traffic_intensity_right}', intensity_position_right_lane, 
                    font, font_scale, font_color, 2, cv2.LINE_AA)

        # Ghi lại khung hình đã xử lý vào video đầu ra
        out.write(processed_frame)

        # Hiển thị video đã xử lý
        cv2.imshow("Đếm đối tượng và phân tích giao thông", processed_frame)

    # Kiểm tra phím nhấn
    key = cv2.waitKey(3) & 0xFF
    if key == ord('q'):  # Nhấn 'q' để thoát
        break
    elif key == ord('p'):  # Nhấn 'p' để tạm dừng hoặc tiếp tục
        paused = not paused


# Giải phóng tài nguyên và đóng các cửa sổ
cap.release()
out.release()
cv2.destroyAllWindows()